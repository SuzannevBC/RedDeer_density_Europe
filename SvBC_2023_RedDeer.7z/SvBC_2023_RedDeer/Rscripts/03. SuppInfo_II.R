library("mgcv")
library("dplyr")
library("DHARMa")
library("ggplot2")
library("sjPlot")
library("corrplot")
library("effects")
library("rgdal")
library("glmmTMB")

# ----------------------------------------------------------------
#### 5-km buffer
# ---------------------------------------------------------------


#### Data preparation ####
# ----------------------------------------------------------------

red_EU_5km<- read.csv("Data\\Supp_SvBC_RedDeer_5km.csv", header = T, sep = ",")
red_EU_5km<- red_EU_5km[,-1]

# Change all character to factor
red_EU_5km[sapply(red_EU_5km, is.character)]<- lapply(red_EU_5km[sapply(red_EU_5km, is.character)], as.factor) 

names(red_EU_5km)[names(red_EU_5km) == "IUCN_Catergory"]<- "IUCN_Category"

#### Remove areas discussed co-authors (i.e. enclosures) #
red_EU_5km<- red_EU_5km[!(red_EU_5km$Study_area == "Altopiano di Budduso" | red_EU_5km$Study_area == "Ulassai" | red_EU_5km$Study_area == "Montarbu" | red_EU_5km$Study_area == "Sarcidano" | red_EU_5km$Study_area == "Monte Arci" | red_EU_5km$Study_area == "Tramonti" | red_EU_5km$Study_area == "Monticolo"),]

red_EU_5km$Year_publ[is.na(red_EU_5km$Year_publ)]<- "3000"
red_EU_5km$Year_publ<- as.numeric(red_EU_5km$Year_publ)

#### Drop forest integrity and biogeographic regions - contain NA's and not important for further analyses
red_EU_5km<- red_EU_5km[!names(red_EU_5km) %in% c("Forest_integrity", "Biogeographic")]

red_EU_5km<- na.omit(red_EU_5km)

red_EU_5km$hunting<- as.factor(red_EU_5km$hunting)

# add IUCN variable
red_EU_5km$Protected<- ifelse(red_EU_5km$IUCN_Category == "I", "Strict", 
                              ifelse(red_EU_5km$IUCN_Category == "II", "Strict", 
                                     ifelse(red_EU_5km$IUCN_Category == "III", "Strict", 
                                            ifelse(red_EU_5km$IUCN_Category == "IV", "Less strict", 
                                                   ifelse(red_EU_5km$IUCN_Category == "V", "Less strict", "Not Protected")))))
red_EU_5km$Protected<- as.factor(red_EU_5km$Protected)

# Change Predation column as only very few observation with Bear
red_EU_5km$Predation_adj<- ifelse(red_EU_5km$Predation == "None", "None", 
                                  ifelse(red_EU_5km$Predation == "All", "All", 
                                         ifelse(red_EU_5km$Predation == "Wolf_only", "Wolf", 
                                                ifelse(red_EU_5km$Predation == "Wolf_lynx", "Wolf/lynx", 
                                                       ifelse(red_EU_5km$Predation == "Lynx_only", "Lynx", "Bear")))))

red_EU_5km$Predation_adj <- as.factor(red_EU_5km$Predation_adj)
red_EU_5km$Predation_adj<- relevel(red_EU_5km$Predation_adj, ref = "None")

# Only include densities obtained from papers >2000
red_EU_5km<- red_EU_5km[which(red_EU_5km$Year_publ > 2000),]

# Change hunting variable for interpretation
red_EU_5km$hunting<- ifelse(red_EU_5km$hunting == "0", "Non-hunted", "Hunted")
red_EU_5km$hunting<- as.factor(red_EU_5km$hunting)

# Set reference group predators
red_EU_5km$Predation_adj<- relevel(red_EU_5km$Predation_adj, ref = "None")
red_EU_5km$Predation<- relevel(red_EU_5km$Predation, ref = "None")

#### Pre-modelling exploratory analyses
# --------------------------------------------------------------

red_EU_corr_5km<- red_EU_5km %>%
  select("Deer_density", "Human_influence_index","NDVI", "NPP", "Bear_presence", "Wolf_presence", "Lynx_presence", "NDSI_Snow_Cover", "Tree_canopy_cover", "Palmer_drought_summer")

#### Correlation
vprint <- function(x, ...) {
  require(htmltools)
  html_print(pre(paste0(capture.output(print(x, ...)), collapse="\n")))
} 

corr_redf<- cor(red_EU_corr_5km)

vprint(red_EU_corr_5km)

res1<- cor.mtest(red_EU_corr_5km, conf.level = .95)
corrplot(corr_redf, type = "lower", addCoef.col = "white", number.cex = 0.6, p.mat = res1$p, sig.level = .05, insig = "blank") #

#### Linear relationships between all individual variables
plot(red_EU_5km$Deer_density ~ red_EU_5km$Human_influence_index, xlab = "Human Influence index", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_5km$Deer_density ~ red_EU_5km$Human_influence_index))
plot(red_EU_5km$Deer_density ~ red_EU_5km$NPP, xlab = "Net primary productivity", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_5km$Deer_density ~ red_EU_5km$NPP)) 
plot(red_EU_5km$Deer_density ~ red_EU_5km$NDSI_Snow_Cover, xlab = "NDSI", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_5km$Deer_density ~ red_EU_5km$NDSI_Snow_Cover))
plot(red_EU_5km$Deer_density ~ red_EU_5km$Tree_canopy_cover, xlab = "Tree canopy cover", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_5km$Deer_density ~ red_EU_5km$Tree_canopy_cover))
plot(red_EU_5km$Deer_density ~ red_EU_5km$Palmer_drought_summer, xlab = "Palmer drought index", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_5km$Deer_density ~ red_EU_5km$Palmer_drought_summer))

boxplot(red_EU_5km$Deer_density ~ red_EU_5km$hunting, xlab = "", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5)
boxplot(red_EU_5km$Deer_density ~ red_EU_5km$Predation_adj, xlab = "", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5)
boxplot(red_EU_5km$Deer_density ~ red_EU_5km$Protected, xlab = "", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5)


#### Model 
# ---------------------------------------------------------------
gam_all_5km<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, data = red_EU_5km)


#### Post-modelling diagnostics ####
# ----------------------------------------------------------------

sim_gam_rev5km<-simulateResiduals(gam_all_5km) 
x11()
plot(sim_gam_rev5km)

gam.check(gam_all_5km) 

concurvity(gam_all_5km) 
concurvity(gam_all_5km, full = FALSE)


#### Model Results
# ----------------------------------------------------------------

anova(gam_all_5km)
summary(gam_all_5km)


# --------------------------------------------------------------
#### 5000 x 5000 resolution
# ----------------------------------------------------------------

#### Data preparation ####
# ----------------------------------------------------------------

#### Add data calculated Google Earth Engine #### 

NDVI_5000<- read.csv("Data\\spatial\\ndvi_revision_5000.csv", header = T, sep = ",")
NPP_5000<- read.csv("Data\\spatial\\npp_revision_5000.csv", header = T, sep = ",") 
NDSI_5000<-  read.csv("Data\\spatial\\NDSI_revision_5000.csv", header = T, sep = ",") # 0
TDC_5000<- read.csv("Data\\spatial\\TDC_revision_5000.csv", header = T, sep = ",") # 0
# HII_5000<- read.csv("Data\\spatial_EarthEngine\\Revision\\HII_revision_5000.csv", header = T, sep = ",")

# somehow Rissue dataset, load new
HII_5000<- read.csv2("Data\\spatial\\HII_revision_5000_trenned.csv", header =T)

# Change column names as some dataset contain same names, confusing after combining
names(NDVI_5000)[names(NDVI_5000) == "NDVI"]<- "NDVI_5000"
names(NPP_5000)[names(NPP_5000) == "Npp"]<- "NPP_5000"
names(NDSI_5000)[names(NDSI_5000) == "NDSI_Snow_Cover"]<- "NDSI_5000"
names(TDC_5000)[names(TDC_5000) == "tree_canopy_cover"]<- "Tree_canopy_cover_5000"
names(HII_5000)[names(HII_5000) == "b1"] <- "Human_influence_index_5000"



# Combine dataframes
GEE_comb<- cbind(NDVI_5000, NPP_5000, NDSI_5000, TDC_5000, HII_5000) 
GEE_comb<- GEE_comb[,-c(1,8:13,15:22,24:34,36:42,44,45)]

names(GEE_comb)[names(GEE_comb) == "StudyAre_1"]<- "Study_area"

# # Combining two study areas wrong - change name
# Loc_env$Study_area<- gsub("Plateau du Coscione et massif de lâ€™Incudine","Plateau du Coscione et massif de l’Incudine", Loc_env$Study_area)
# Loc_env$Study_area<- gsub("Val di Rose M.Sterpi dâ€™Alto M. Boccanera","Val di Rose M.Sterpi d’Alto M. Boccanera", Loc_env$Study_area)

Loc_env_comb<- merge(red_EU, GEE_comb, by = "Study_area")
Loc_env_comb<- Loc_env_comb[,-c(26:28,30)]
names(Loc_env_comb)[names(Loc_env_comb) == "Latitude.x"]<- "Latitude"
names(Loc_env_comb)[names(Loc_env_comb) == "Longitude.x"]<- "Longitude"

# Apply scaling factor and round values
Loc_env_comb$NDVI_5000<- round((Loc_env_comb$NDVI_5000*0.0001), digits = 3)
Loc_env_comb$NPP_5000<- round((Loc_env_comb$NPP_5000*0.0001), digits = 3)
Loc_env_comb$NDSI_5000<- round((Loc_env_comb$NDSI_5000), digits = 1)
Loc_env_comb$Tree_canopy_cover_5000<- round((Loc_env_comb$Tree_canopy_cover_5000), digits = 1)

Loc_env_comb$Human_influence_index_5000<- as.numeric(Loc_env_comb$Human_influence_index_5000)
Loc_env_comb$Human_influence_index_5000<- round((Loc_env_comb$Human_influence_index_5000), digits = 2)

Loc_env_comb<- Loc_env_comb[,c(1,3,2,4:30)]

# Change all character to factor
Loc_env_comb[sapply(Loc_env_comb, is.character)]<- lapply(Loc_env_comb[sapply(Loc_env_comb, is.character)], as.factor) 

red_EU_rev_5000<- Loc_env_comb

# Change all character to factor
red_EU_rev_5000[sapply(red_EU_rev_5000, is.character)]<- lapply(red_EU_rev_5000[sapply(red_EU_rev_5000, is.character)], as.factor) 

names(red_EU_rev_5000)[names(red_EU_rev_5000) == "IUCN_Catergory"]<- "IUCN_Category"
names(red_EU_rev_5000)[names(red_EU_rev_5000) == "Year_publ.x"]<- "Year_publ"
names(red_EU_rev_5000)[names(red_EU_rev_5000) == "Country.x"]<- "Country"
names(red_EU_rev_5000)[names(red_EU_rev_5000) == "Latitude.x"]<- "Latitude"

#### Remove areas as discused with co-authors (i.e. enclosures) #
red_EU_rev_5000<- red_EU_rev_5000[!(red_EU_rev_5000$Study_area == "Altopiano di Budduso" | red_EU_rev_5000$Study_area == "Ulassai" | red_EU_rev_5000$Study_area == "Montarbu" | red_EU_rev_5000$Study_area == "Sarcidano" | red_EU_rev_5000$Study_area == "Monte Arci" | red_EU_rev_5000$Study_area == "Tramonti" | red_EU_rev_5000$Study_area == "Monticolo"),]


#### Drop forest integrity and biogeographic regions - contain NA's and not important for further analyses
red_EU_rev_5000<- red_EU_rev_5000[!names(red_EU_rev_5000) %in% c("Forest_integrity", "Biogeographic")]

red_EU_rev_5000<- na.omit(red_EU_rev_5000)

# add IUCN variable
red_EU_rev_5000$Protected<- ifelse(red_EU_rev_5000$IUCN_Category == "I", "Strict", 
                                   ifelse(red_EU_rev_5000$IUCN_Category == "II", "Strict", 
                                          ifelse(red_EU_rev_5000$IUCN_Category == "III", "Strict", 
                                                 ifelse(red_EU_rev_5000$IUCN_Category == "IV", "Less strict", 
                                                        ifelse(red_EU_rev_5000$IUCN_Category == "V", "Less strict", "Not Protected")))))
red_EU_rev_5000$Protected<- as.factor(red_EU_rev_5000$Protected)

# Change Predation column as only very few observation with Bear
red_EU_rev_5000$Predation_adj<- ifelse(red_EU_rev_5000$Predation == "None", "None", 
                                       ifelse(red_EU_rev_5000$Predation == "All", "All", 
                                              ifelse(red_EU_rev_5000$Predation == "Wolf_only", "Wolf", 
                                                     ifelse(red_EU_rev_5000$Predation == "Wolf_lynx", "Wolf/Lynx", 
                                                            ifelse(red_EU_rev_5000$Predation == "Lynx_only", "Lynx", "Bear")))))

red_EU_rev_5000$Predation_adj <- as.factor(red_EU_rev_5000$Predation_adj)
red_EU_rev_5000$Predation_adj<- relevel(red_EU_rev_5000$Predation_adj, ref = "None")

# Only include densities obtained from papers >2000
red_EU_rev_5000<- red_EU_rev_5000[which(red_EU_rev_5000$Year_publ > 2000),]

# Change hunting variable for interpretation
red_EU_rev_5000$hunting<- ifelse(red_EU_rev_5000$hunting == "0", "Non-hunted", "Hunted")
red_EU_rev_5000$hunting<- as.factor(red_EU_rev_5000$hunting)

# Set reference group predators
red_EU_rev_5000$Predation_adj<- relevel(red_EU_rev_5000$Predation_adj, ref = "None")
red_EU_rev_5000$Predation<- relevel(red_EU_rev_5000$Predation, ref = "None")


#### Pre-modelling exploratory analyses
# --------------------------------------------------------------

red_EU_corr_5000<- red_EU_rev_5000 %>%
  select("Deer_density", "Human_influence_index_5000","NDVI_5000", "NPP_5000", "Bear_presence", "Wolf_presence", "Lynx_presence", "NDSI_5000", "Tree_canopy_cover_5000", "Palmer_drought_summer")

#### Correlation
vprint <- function(x, ...) {
  require(htmltools)
  html_print(pre(paste0(capture.output(print(x, ...)), collapse="\n")))
} 

corr_redf<- cor(red_EU_corr_5000)

vprint(red_EU_corr_5000)

res1<- cor.mtest(red_EU_corr_5000, conf.level = .95)
corrplot(corr_redf, type = "lower", addCoef.col = "white", number.cex = 0.6, p.mat = res1$p, sig.level = .05, insig = "blank") #

#### Linear relationships between all individual variables
plot(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$Human_influence_index_5000, xlab = "Human Influence index", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$Human_influence_index_5000))
plot(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$NPP_5000, xlab = "Net primary productivity", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$NPP_5000)) 
plot(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$NDSI_5000, xlab = "NDSI", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$NDSI_5000))
plot(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$Tree_canopy_cover_5000, xlab = "Tree canopy cover", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$Tree_canopy_cover_5000))
plot(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$Palmer_drought_summer, xlab = "Palmer drought index", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$Palmer_drought_summer))

boxplot(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$hunting, xlab = "", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5)
boxplot(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$Predation_adj, xlab = "", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5)
boxplot(red_EU_rev_5000$Deer_density ~ red_EU_rev_5000$Protected, xlab = "", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5)


#### Model 
# ---------------------------------------------------------------
gam10km_rev_5000<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index_5000, by = Predation_adj)+ s(NPP_5000, by = Predation_adj)+ s(Tree_canopy_cover_5000)+ s(NDSI_5000) + s(Palmer_drought_summer) + Protected, data = red_EU_rev_5000)


#### Post-modelling diagnostics ####
# ----------------------------------------------------------------

sim_gam_rev5000<-simulateResiduals(gam10km_rev_5000) 
x11()
plot(sim_gam_rev5000)

gam.check(gam10km_rev_5000) 

concurvity(gam10km_rev_5000) 
concurvity(gam10km_rev_5000, full = FALSE)


#### Model Results
# ----------------------------------------------------------------

anova(gam10km_rev_5000)
summary(gam10km_rev_5000)