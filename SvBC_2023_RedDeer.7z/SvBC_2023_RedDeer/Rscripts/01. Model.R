library("mgcv")
library("dplyr")
library("DHARMa")
library("ggplot2")
library("sjPlot")
library("corrplot")
library("effects")
library("rgdal")

#---------------------------------------------
####  1. Data preparation #### 
# --------------------------------------------

red_EU<-read.csv("Data\\Data_SvBC_RedDeer.csv", header = T, sep = ",")
red_EU<- red_EU[,-1]

#### Add density estimation method ####
loc_mod<-read.csv("Data\\Data_SvBC_RedDeer_method.csv", header = T, sep = ";")

red_EU_review<- merge(red_EU, loc_mod, by = c("Study_area","Longitude" ,"Deer_density"))
red_EU_review<- distinct(red_EU_review)

red_EU_review<- red_EU_review[-c(26:28)]

# Change all characters to factor
red_EU_review[sapply(red_EU_review, is.character)]<- lapply(red_EU_review[sapply(red_EU_review, is.character)], as.factor) 

names(red_EU_review)[names(red_EU_review) == "IUCN_Catergory"]<- "IUCN_Category"
names(red_EU_review)[names(red_EU_review) == "Year_publ.x"]<- "Year_publ"
names(red_EU_review)[names(red_EU_review) == "Country.x"]<- "Country"
names(red_EU_review)[names(red_EU_review) == "Latitude.x"]<- "Latitude"

#### Remove study sites as discussed co-authors (i.e. enclosures) #
red_EU_review<- red_EU_review[!(red_EU_review$Study_area == "Altopiano di Budduso" | red_EU_review$Study_area == "Ulassai" | red_EU_review$Study_area == "Montarbu" | red_EU_review$Study_area == "Sarcidano" | red_EU_review$Study_area == "Monte Arci" | red_EU_review$Study_area == "Tramonti" | red_EU_review$Study_area == "Monticolo"),]


#### Drop forest integrity and biogeographic regions - contain NA's and not important for further analyses
red_EU_review<- red_EU_review[!names(red_EU_review) %in% c("Forest_integrity", "Biogeographic")]


# Final cleaning of data
red_EU_review<- na.omit(red_EU_review)

# add IUCN variable
red_EU_review$Protected<- ifelse(red_EU_review$IUCN_Category == "I", "Strict", 
                                 ifelse(red_EU_review$IUCN_Category == "II", "Strict", 
                                        ifelse(red_EU_review$IUCN_Category == "III", "Strict", 
                                               ifelse(red_EU_review$IUCN_Category == "IV", "Less strict", 
                                                      ifelse(red_EU_review$IUCN_Category == "V", "Less strict", "Not Protected")))))
red_EU_review$Protected<- as.factor(red_EU_review$Protected)

# Change Predation column as only very few observation with Bear
red_EU_review$Predation_adj<- ifelse(red_EU_review$Predation == "None", "None", 
                                     ifelse(red_EU_review$Predation == "All", "All", 
                                            ifelse(red_EU_review$Predation == "Wolf_only", "Wolf", 
                                                   ifelse(red_EU_review$Predation == "Wolf_lynx", "Wolf/Lynx", 
                                                          ifelse(red_EU_review$Predation == "Lynx_only", "Lynx", "Bear")))))

red_EU_review$Predation_adj <- as.factor(red_EU_review$Predation_adj)
red_EU_review$Predation_adj<- relevel(red_EU_review$Predation_adj, ref = "None")

# Only include densities obtained from papers >2000
red_EU_review<- red_EU_review[which(red_EU_review$Year_publ > 2000),]

# Change hunting variable for interpretation
red_EU_review$hunting<- ifelse(red_EU_review$hunting == "0", "Non-hunted", "Hunted")
red_EU_review$hunting<- as.factor(red_EU_review$hunting)

# Set reference group predators
red_EU_review$Predation_adj<- relevel(red_EU_review$Predation_adj, ref = "None")
red_EU_review$Predation<- relevel(red_EU_review$Predation, ref = "None")

# --------------------------------------------------------------
#### Pre-modelling exploratory analyses
# --------------------------------------------------------------

red_EU_corr<- red_EU_review %>%
  select("Deer_density", "Human_influence_index","NDVI", "NPP", "Bear_presence", "Wolf_presence", "Lynx_presence", "NDSI_Snow_Cover", "Tree_canopy_cover", "Palmer_drought_summer")

#### Correlation
vprint <- function(x, ...) {
  require(htmltools)
  html_print(pre(paste0(capture.output(print(x, ...)), collapse="\n")))
} 

corr_redf<- cor(red_EU_corr)

vprint(red_EU_corr)

res1<- cor.mtest(red_EU_corr, conf.level = .95)
corrplot(corr_redf, type = "lower", addCoef.col = "white", number.cex = 0.6, p.mat = res1$p, sig.level = .05, insig = "blank") #

#### Linear relationships between all individual variables
plot(red_EU_review$Deer_density ~ red_EU_review$Human_influence_index, xlab = "Human Influence index", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_review$Deer_density ~ red_EU_review$Human_influence_index))
plot(red_EU_review$Deer_density ~ red_EU_review$NPP, xlab = "Net primary productivity", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_review$Deer_density ~ red_EU_review$NPP)) 
plot(red_EU_review$Deer_density ~ red_EU_review$NDSI_Snow_Cover, xlab = "NDSI", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_review$Deer_density ~ red_EU_review$NDSI_Snow_Cover))
plot(red_EU_review$Deer_density ~ red_EU_review$Tree_canopy_cover, xlab = "Tree canopy cover", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_review$Deer_density ~ red_EU_review$Tree_canopy_cover))
plot(red_EU_review$Deer_density ~ red_EU_review$Palmer_drought_summer, xlab = "Palmer drought index", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5); abline(lm(red_EU_review$Deer_density ~ red_EU_review$Palmer_drought_summer))

boxplot(red_EU_review$Deer_density ~ red_EU_review$hunting, xlab = "", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5)
boxplot(red_EU_review$Deer_density ~ red_EU_review$Predation_adj, xlab = "", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5)
boxplot(red_EU_review$Deer_density ~ red_EU_review$Protected, xlab = "", ylab= "Red deer density (100 ha-1)", cex.lab = 1.5)

# ---------------------------------------------------------------
#### Model 
# ---------------------------------------------------------------

gam10km_rev<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, data = red_EU_review)

# ----------------------------------------------------------------
#### Post-modelling diagnostics ####
# ----------------------------------------------------------------
sim_gam_rev<-simulateResiduals(gam10km_rev) 
x11()
plot(sim_gam_rev)

gam.check(gam10km_rev) 
k.check(gam10km_rev, subsample = 5000, n.rep = 400) 

concurvity(gam10km_rev)
concurvity(gam10km_rev, full = FALSE)

# spatial Autocorrelation
red_EU_review$location<- factor( apply(cbind( red_EU_review$Latitude, red_EU_review$Longitude), 1, toString))
d = ! duplicated(red_EU_review$location) 

sim_gam_rev2 = recalculateResiduals(sim_gam_rev, group = as.numeric(red_EU_review$location))
plot(sim_gam_rev2)
testSpatialAutocorrelation(sim_gam_rev2, red_EU_review$Latitude[d], red_EU_review$Longitude[d]) 

# ----------------------------------------------------------------
#### Model Results
# ----------------------------------------------------------------

anova(gam10km_rev)
summary(gam10km_rev)

save.image(file = "Results\\Model.RData")
