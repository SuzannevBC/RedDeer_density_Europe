library("mgcv")
library("dplyr")
library("DHARMa")
library("ggplot2")
library("sjPlot")
library("corrplot")
library("effects")
library("rgdal")

load("Results\\Model.RData")
# ---------------------------------------------------------------
#### Model 
# ---------------------------------------------------------------

gam10km_rev<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, data = red_EU_review)

# ---------------------------------------------------------------
### Boxplots parametric coefficients #### 
# ---------------------------------------------------------------
preds<- predict(gam10km_rev, red_EU_review, type = "response")

# Hunting
Hunt_boxplot<- ggplot(data = red_EU_review, mapping = aes(x = hunting, y = preds)) +
  geom_point(shape = 20, size = 1, position = "jitter", colour = "gray50") + 
  geom_boxplot(data = red_EU_review, alpha = 0.6, fill = "gray75", outlier.shape = NA) +
  theme_bw() + theme(legend.position = "None") + theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),  axis.line = element_line(colour = "grey"))+ theme(axis.title.x = element_blank()) + labs(y = "Red deer density (100 ha-1)") + theme(axis.text.x = element_text(color = "black"), axis.text.y = element_text(colour = "black")) + theme(text = element_text(size = 20, colour = "black")) 

# Predation
Predation_boxplot<- ggplot(data = red_EU_review, mapping = aes(x = Predation_adj, y = preds)) +
  geom_point(shape = 20, size = 1, position = "jitter", colour = "gray50") + 
  geom_boxplot(data = red_EU_review, alpha = 0.6, fill = "gray75", outlier.shape = NA) +
  theme_bw() + theme(legend.position = "None") + theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),  axis.line = element_line(colour = "grey"))+ theme(axis.title.x = element_blank()) + labs(y = "Red deer density (100 ha-1)")+ theme(axis.text.x = element_text(color = "black"), axis.text.y = element_text(colour = "black")) + theme(text = element_text(size = 20)) 


tiff("Results\\Hunt_Pred_10km.tiff", width = 6400, height = 3200, units = "px", res = 600, compression = "lzw")
par(mfrow=c(1,2),mar=c(5,5,1,1))

gridExtra::grid.arrange(Hunt_boxplot, Predation_boxplot, ncol = 2)

dev.off()

# --------------------------------------------------------------------
#### Plot smooths #### 
# --------------------------------------------------------------------

# Function
plotsmooth <- function(fit,se.fit,S,k1,k2,lty=lty){
  P <- fit
  ps <- se.fit
  ucl <- P+1.96*ps
  lcl <- P-1.96*ps
  i.for <- c(1:(length(S)))
  i.back <- rev(i.for)
  x.polygon <- c(S[i.for],rev(S[i.for]))
  y.polygon <- c( ucl[i.for] , lcl[i.back] )
  polygon( x.polygon , y.polygon , col =k2, border = NA)
  lines( S, P[i.for], col = k1 , lwd = 3 ,lty=lty)
  # Smooth terms
}

X<- plot(gam10km_rev, residuals = T, by.resids = T)

#### Human influence index * Predation ####
tiff("Results\\HII_ANPred_10km.tiff", width = 3200, height = 3200, units = "px", res = 600, compression = "lzw")
par(mfrow=c(1,1),mar=c(6,5,1,1),cex.axis=1.4, cex.lab = 1.8)

plot(1,1,type="n",ylim=range(c(-6,6)), xlim = range(c(red_EU_review$Human_influence_index))
     ,ylab="Centred red deer density (100 ha-1)", 
     xlab="", cex.lab = 1.4, las = 1)
plotsmooth(X[[2]]$fit, X[[2]]$se, X[[2]]$x,"black", adjustcolor("gray90", alpha.f = 0.6), 1) # All carnivores;sign
points(red_EU_review[which(red_EU_review$Predation_adj=="All"),]$Human_influence_index, X[[2]]$p.resid[which(red_EU_review$Predation_adj=="All")], col = "gray20", pch = 20, lwd = 1)
plotsmooth(X[[1]]$fit,X[[1]]$se,X[[1]]$x,"black",adjustcolor("gray70", alpha.f = 0.5), 2) # No carnivores;trend
points( red_EU_review[which(red_EU_review$Predation_adj=="None"),]$Human_influence_index,X[[1]]$p.resid[which(red_EU_review$Predation_adj=="None")], col = alpha("gray50", 0.4), pch = 20, lwd = 1, cex = 1.0)
abline(h=0,lty=3,lwd=1.5)
mtext("Human influence index", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(red_EU_review$Human_influence_index)
legend(6,-9.3, inset = c(-0.5, 0),xpd = T, legend = c("All large carnivores", "No large carnivores"), col = c("black", "black"), lty = 1:2, lwd = 3, cex = 1.02, box.lty = 0, horiz = T)

dev.off()


### Net primary productivity * Predation ####

tiff("Results\\NPP_ANPred_10km.tiff", width = 3200, height = 3200, units = "px", res = 600, compression = "lzw")
par(mfrow=c(1,1),mar=c(6,5,1,1),cex.axis=1.4, cex.lab = 1.8)

plot(1,1,type="n",ylim=range(c(-10,10)), xlim = range(c(red_EU_review$NPP))
     ,ylab="Centred red deer density (100 ha-1)", 
     xlab="", cex.lab = 1.4, las = 1)
plotsmooth(X[[8]]$fit, X[[8]]$se, X[[8]]$x,"black", adjustcolor("gray90", alpha.f = 0.6), 1) # All carnivores; not sign
points(red_EU_review[which(red_EU_review$Predation_adj=="All"),]$NPP, X[[7]]$p.resid[which(red_EU_review$Predation_adj=="All")], col = "gray20", pch = 20, lwd = 1)
plotsmooth(X[[7]]$fit,X[[7]]$se,X[[7]]$x,"black",adjustcolor("gray70", alpha.f = 0.5), 2) # No large carnivores: not sign
points(red_EU_review[which(red_EU_review$Predation_adj=="None"),]$NPP, X[[7]]$p.resid[which(red_EU_review$Predation_adj=="None")], col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
mtext("Net primary productivity", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(red_EU_review$NPP)
legend(0.05,-15.5, inset = c(-0.5, 0),xpd = T, legend = c("All large carnivores", "No large carnivores"), col = c("black", "black"), lty = 1:2, lwd = 3, cex = 1.02, box.lty = 0, horiz = T)

dev.off()


#### Environmental plots ####

tiff("Results\\Env_all_10km.tiff", width = 9600, height = 3200, units = "px", res = 600, compression = "lzw")
par(mfrow=c(1,3),mar=c(5,5,1,1),cex.axis=1.8)

plot(1,1,type="n",ylim=range(c(-3,3)), xlim = range(c(red_EU_review$Tree_canopy_cover))
     ,ylab="Red deer density (100 ha-1)", 
     xlab="", cex.lab = 2.0, las = 1)
plotsmooth(X[[13]]$fit, X[[13]]$se, X[[13]]$x,"black", adjustcolor("gray75", alpha.f = 0.6), 1) 
points(red_EU_review$Tree_canopy_cover, X[[13]]$p.resid, col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
abline(h=0,lty=3,lwd=1.5)
mtext("Tree canopy cover", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(red_EU_review$Tree_canopy_cover)

plot(1,1,type="n",ylim=range(c(-3,3)), xlim = range(c(red_EU_review$NDSI_Snow_Cover))
     ,ylab="Red deer density (100 ha-1)", 
     xlab="", cex.lab = 2.0, las = 1)
plotsmooth(X[[14]]$fit, X[[14]]$se, X[[14]]$x, "black", adjustcolor("gray75", alpha.f = 0.6), 2)
points(red_EU_review$NDSI_Snow_Cover, X[[14]]$p.resid, col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
mtext("NDSI", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(red_EU_review$NDSI_Snow_Cover)

plot(1,1,type="n",ylim=range(c(-3,3)), xlim = range(c(red_EU_review$Palmer_drought_summer))
     ,ylab="Red deer density (100 ha-1)", 
     xlab="", cex.lab = 2.0, las = 1)
plotsmooth(X[[15]]$fit, X[[15]]$se, X[[15]]$x, "black", adjustcolor("gray75", alpha.f = 0.6), 2)
points(red_EU_review$Palmer_drought_summer, X[[15]]$p.resid, col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
mtext("Palmer drought index", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(red_EU_review$Palmer_drought_summer)

dev.off()



