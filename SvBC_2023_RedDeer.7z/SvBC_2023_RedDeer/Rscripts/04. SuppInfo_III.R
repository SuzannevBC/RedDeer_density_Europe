
load("Results\\Model.RData")

# --------------------------------------------------------
# 1. Check stability model, randomly deleting 10% of data ####
# --------------------------------------------------------

set.seed(69365)
red_stab<- red_EU_review[-sample(1:nrow(red_EU_review), 50),]

gam10km_stab<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, data = red_stab)

# Post-modelling diagnostics
sim_gam_stab<-simulateResiduals(gam10km_stab) 
x11()
plot(sim_gam_stab)

gam.check(gam10km_stab)

# Results 
summary(gam10km_stab) 
anova(gam10km_stab)

#### Figures ####

preds_stab<- predict(gam10km_stab, red_stab, type = "response")

# Hunting
ggplot(data = red_stab, mapping = aes(x = hunting, y = preds_stab)) +
  geom_point(shape = 20, size = 1, position = "jitter", colour = "gray50") + 
  geom_boxplot(data = red_stab, alpha = 0.6, fill = "gray75", outlier.shape = NA) +
  theme_bw() + theme(legend.position = "None") + theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),  axis.line = element_line(colour = "grey"))+ theme(axis.title.x = element_blank()) + labs(y = "Red deer density (100 ha-1)") + theme(axis.text.x = element_text(color = "black"), axis.text.y = element_text(colour = "black")) + theme(text = element_text(size = 40, colour = "black")) 

# Predation
ggplot(data = red_stab, mapping = aes(x = Predation_adj, y = preds_stab)) +
  geom_point(shape = 20, size = 1, position = "jitter", colour = "gray50") + 
  geom_boxplot(data = red_stab, alpha = 0.6, fill = "gray75", outlier.shape = NA) +
  theme_bw() + theme(legend.position = "None") + theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),  axis.line = element_line(colour = "grey"))+ theme(axis.title.x = element_blank()) + labs(y = "Red deer density (100 ha-1)")+ theme(axis.text.x = element_text(color = "black"), axis.text.y = element_text(colour = "black")) + theme(text = element_text(size = 40, colour = "black")) 


# Function
plotsmooth <- function(fit,se.fit,S,k1,k2,lty=lty){
  P <- fit
  ps <- se.fit
  ucl <- P+1.96*ps
  lcl <- P-1.96*ps
  i.for <- c(1:(length(S)))
  i.back <- rev(i.for)
  x.polygon <- c(S[i.for],rev(S[i.for]))
  y.polygon <- c( ucl[i.for] , lcl[i.back] )
  polygon( x.polygon , y.polygon , col =k2, border = NA)
  lines( S, P[i.for], col = k1 , lwd = 3 ,lty=lty)
  # Smooth terms
}

X<- plot(gam10km_stab, residuals = T, by.resids = T)

# HII * Predation 
plot(1,1,type="n",ylim=range(c(-6,6)), xlim = range(c(red_stab$Human_influence_index))
     ,ylab="Centred red deer density (100 ha-1)", 
     xlab="", cex.lab = 1.8, las = 1)
plotsmooth(X[[2]]$fit, X[[2]]$se, X[[2]]$x,"black", adjustcolor("gray90", alpha.f = 0.6), 1) # All carnivores;sign
points(red_stab[which(red_stab$Predation_adj=="All"),]$Human_influence_index, X[[2]]$p.resid[which(red_stab$Predation_adj=="All")], col = "gray20", pch = 20, lwd = 1)
plotsmooth(X[[1]]$fit,X[[1]]$se,X[[1]]$x,"black",adjustcolor("gray70", alpha.f = 0.5), 2) # No carnivores;trend
points(red_stab[which(red_stab$Predation_adj=="None"),]$Human_influence_index,X[[1]]$p.resid[which(red_stab$Predation_adj=="None")], col = alpha("gray50", 0.4), pch = 20, lwd = 1, cex = 1.0)
abline(h=0,lty=3,lwd=1.5)
mtext("Human influence index", side = 1, outer = FALSE, cex = 1.8, line = 3, adj = 0.5)
rug(red_stab$Human_influence_index)
legend(12.5,7.5, inset = c(-0.5, 0),xpd = T, legend = c("All large carnivores", "No large carnivores"), col = c("black", "black"), lty = 1:2, lwd = 3, cex = 1.8, box.lty = 0, horiz = T)


# NPP * Predation

plot(1,1,type="n",ylim=range(c(-10,10)), xlim = range(c(red_stab$NPP))
     ,ylab="Centred red deer density (100 ha-1)", 
     xlab="", cex.lab = 1.8, las = 1)
plotsmooth(X[[8]]$fit, X[[8]]$se, X[[8]]$x,"black", adjustcolor("gray90", alpha.f = 0.6), 1) # All carnivores; not sign
points(red_stab[which(red_stab$Predation_adj=="All"),]$NPP, X[[7]]$p.resid[which(red_stab$Predation_adj=="All")], col = "gray20", pch = 20, lwd = 1)
plotsmooth(X[[7]]$fit,X[[7]]$se,X[[7]]$x,"black",adjustcolor("gray70", alpha.f = 0.5), 2) # No large carnivores: not sign
points(red_stab[which(red_stab$Predation_adj=="None"),]$NPP, X[[7]]$p.resid[which(red_stab$Predation_adj=="None")], col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
mtext("Net primary productivity", side = 1, outer = FALSE, cex = 1.8, line = 3, adj = 0.5)
rug(red_stab$NPP)
legend(0.25,12.5, inset = c(-0.5, 0),xpd = T, legend = c("All large carnivores", "No large carnivores"), col = c("black", "black"), lty = 1:2, lwd = 3, cex = 1.8, box.lty = 0, horiz = T)


# Environmental plots

plot(1,1,type="n",ylim=range(c(-3,3)), xlim = range(c(red_stab$Tree_canopy_cover))
     ,ylab="Red deer density (100 ha-1)",
     xlab="", cex.lab = 2.0, las = 1)
plotsmooth(X[[13]]$fit, X[[13]]$se, X[[13]]$x,"black", adjustcolor("gray75", alpha.f = 0.6), 1)
points(red_stab$Tree_canopy_cover, X[[13]]$p.resid, col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
abline(h=0,lty=3,lwd=1.5)
mtext("Tree canopy cover", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(red_stab$Tree_canopy_cover_1000)

plot(1,1,type="n",ylim=range(c(-3,3)), xlim = range(c(red_stab$NDSI_Snow_Cover))
     ,ylab="Red deer density (100 ha-1)",
     xlab="", cex.lab = 2.0, las = 1)
plotsmooth(X[[14]]$fit, X[[14]]$se, X[[14]]$x, "black", adjustcolor("gray75", alpha.f = 0.6), 2)
points(red_stab$NDSI_Snow_Cover, X[[14]]$p.resid, col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
mtext("NDSI", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(red_stab$NDSI_1000)

plot(1,1,type="n",ylim=range(c(-3,3)), xlim = range(c(red_stab$Palmer_drought_summer))
     ,ylab="Red deer density (100 ha-1)",
     xlab="", cex.lab = 2.0, las = 1)
plotsmooth(X[[15]]$fit, X[[15]]$se, X[[15]]$x, "black", adjustcolor("gray75", alpha.f = 0.6), 2)
points(red_stab$Palmer_drought_summer, X[[15]]$p.resid, col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
mtext("Palmer drought index", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(red_stab$Palmer_drought_summer)

# ----------------------------------------------------------
# 2. Randomly change x number of density values by 60% ####
# -----------------------------------------------------------

df2<- red_EU_review

# Model
set.seed(206720)
sample<- sample(seq(0.4, 1.6, by = 0.1), nrow(df2), replace = T)
df2$Deer_density<-df2$Deer_density * sample

gam10km_sa<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, data = df2)

# Post-modelling diagnostics
sim_gam_sa<-simulateResiduals(gam10km_sa) 
x11()
plot(sim_gam_sa)

# Results
summary(gam10km_sa) 
anova(gam10km_sa)

#### Figures ####
preds_sa <- predict(gam10km_sa, df2, type = "response")

# Hunting
ggplot(data = df2, mapping = aes(x = hunting, y = preds_sa)) +
  geom_point(shape = 20, size = 1, position = "jitter", colour = "gray50") + 
  geom_boxplot(data = red_EU_review, alpha = 0.6, fill = "gray75", outlier.shape = NA) +
  theme_bw() + theme(legend.position = "None") + theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),  axis.line = element_line(colour = "grey"))+ theme(axis.title.x = element_blank()) + labs(y = "Red deer density (100 ha-1)") + theme(axis.text.x = element_text(color = "black"), axis.text.y = element_text(colour = "black")) + theme(text = element_text(size = 20, colour = "black")) 

# Predation
ggplot(data = df2, mapping = aes(x = Predation_adj, y = preds_sa)) +
  geom_point(shape = 20, size = 1, position = "jitter", colour = "gray50") + 
  geom_boxplot(data = df2, alpha = 0.6, fill = "gray75", outlier.shape = NA) +
  theme_bw() + theme(legend.position = "None") + theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),  axis.line = element_line(colour = "grey"))+ theme(axis.title.x = element_blank()) + labs(y = "Red deer density (100 ha-1)")+ theme(axis.text.x = element_text(color = "black"), axis.text.y = element_text(colour = "black")) + theme(text = element_text(size = 40, colour = "black")) 

X<- plot(gam10km_sa, residuals = T, by.resids = T)

# HII * Predation 
plot(1,1,type="n",ylim=range(c(-6,6)), xlim = range(c(df2$Human_influence_index))
     ,ylab="Centred red deer density (100 ha-1)", 
     xlab="", cex.lab = 1.8, las = 1)
plotsmooth(X[[2]]$fit, X[[2]]$se, X[[2]]$x,"black", adjustcolor("gray90", alpha.f = 0.6), 1) # All carnivores;sign
points(df2[which(df2$Predation_adj=="All"),]$Human_influence_index, X[[2]]$p.resid[which(df2$Predation_adj=="All")], col = "gray20", pch = 20, lwd = 1)
plotsmooth(X[[1]]$fit,X[[1]]$se,X[[1]]$x,"black",adjustcolor("gray70", alpha.f = 0.5), 2) # No carnivores;trend
points(df2[which(df2$Predation_adj=="None"),]$Human_influence_index,X[[1]]$p.resid[which(df2$Predation_adj=="None")], col = alpha("gray50", 0.4), pch = 20, lwd = 1, cex = 1.0)
abline(h=0,lty=3,lwd=1.5)
mtext("Human influence index", side = 1, outer = FALSE, cex = 1.8, line = 3, adj = 0.5)
rug(df2$Human_influence_index)
legend(12.5,7.5, inset = c(-0.5, 0),xpd = T, legend = c("All large carnivores", "No large carnivores"), col = c("black", "black"), lty = 1:2, lwd = 3, cex = 1.8, box.lty = 0, horiz = T)


# NPP * Predation

plot(1,1,type="n",ylim=range(c(-10,10)), xlim = range(c(df2$NPP))
     ,ylab="Centred red deer density (100 ha-1)", 
     xlab="", cex.lab = 1.8, las = 1)
plotsmooth(X[[8]]$fit, X[[8]]$se, X[[8]]$x,"black", adjustcolor("gray90", alpha.f = 0.6), 1) # All carnivores; not sign
points(df2[which(df2$Predation_adj=="All"),]$NPP, X[[7]]$p.resid[which(df2$Predation_adj=="All")], col = "gray20", pch = 20, lwd = 1)
plotsmooth(X[[7]]$fit,X[[7]]$se,X[[7]]$x,"black",adjustcolor("gray70", alpha.f = 0.5), 2) # No large carnivores: not sign
points(df2[which(df2$Predation_adj=="None"),]$NPP, X[[7]]$p.resid[which(df2$Predation_adj=="None")], col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
mtext("Net primary productivity", side = 1, outer = FALSE, cex = 1.8, line = 3, adj = 0.5)
rug(df2$NPP)
legend(0.25,12.5, inset = c(-0.5, 0),xpd = T, legend = c("All large carnivores", "No large carnivores"), col = c("black", "black"), lty = 1:2, lwd = 3, cex = 1.8, box.lty = 0, horiz = T)


# Environmental plots

plot(1,1,type="n",ylim=range(c(-3,3)), xlim = range(c(df2$Tree_canopy_cover))
     ,ylab="Red deer density (100 ha-1)",
     xlab="", cex.lab = 2.0, las = 1)
plotsmooth(X[[13]]$fit, X[[13]]$se, X[[13]]$x,"black", adjustcolor("gray75", alpha.f = 0.6), 1)
points(df2$Tree_canopy_cover, X[[13]]$p.resid, col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
abline(h=0,lty=3,lwd=1.5)
mtext("Tree canopy cover", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(df2$Tree_canopy_cover_1000)

plot(1,1,type="n",ylim=range(c(-3,3)), xlim = range(c(df2$NDSI_Snow_Cover))
     ,ylab="Red deer density (100 ha-1)",
     xlab="", cex.lab = 2.0, las = 1)
plotsmooth(X[[14]]$fit, X[[14]]$se, X[[14]]$x, "black", adjustcolor("gray75", alpha.f = 0.6), 2)
points(df2$NDSI_Snow_Cover, X[[14]]$p.resid, col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
mtext("NDSI", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(df2$NDSI_1000)

plot(1,1,type="n",ylim=range(c(-3,3)), xlim = range(c(df2$Palmer_drought_summer))
     ,ylab="Red deer density (100 ha-1)",
     xlab="", cex.lab = 2.0, las = 1)
plotsmooth(X[[15]]$fit, X[[15]]$se, X[[15]]$x, "black", adjustcolor("gray75", alpha.f = 0.6), 2)
points(df2$Palmer_drought_summer, X[[15]]$p.resid, col = alpha("gray50", 0.4), pch = 20, lwd = 1)
abline(h=0,lty=3,lwd=1.5)
mtext("Palmer drought index", side = 1, outer = FALSE, cex = 1.4, line = 3, adj = 0.5)
rug(df2$Palmer_drought_summer)

# --------------------------------------------------------
# 3. Delta deviance explained ####
# --------------------------------------------------------

c<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, data = red_EU_review)

c_hunt<- mgcv::gam(log(Deer_density) ~ Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, data = red_EU_review)

c_pred<- mgcv::gam(log(Deer_density) ~ hunting + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, data = red_EU_review)

c_prot<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer), data = red_EU_review)

c_tcc<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-13], data = red_EU_review)

c_ndsi<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-14], data = red_EU_review)

c_pd<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(NPP, by = Predation_adj)+ s(Tree_canopy_cover) + s(NDSI_Snow_Cover) + Protected, sp = c$sp[-15], data = red_EU_review)

# HII
c_HII_n<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-1],data = red_EU_review)

c_HII_a<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-2],data = red_EU_review)

c_HII_b<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-3],data = red_EU_review)

c_HII_l<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-4],data = red_EU_review)

c_HII_w<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-5],data = red_EU_review)

c_HII_wl<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(NPP, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-6],data = red_EU_review)

# NPP
c_NPP_n<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-7],data = red_EU_review)

c_NPP_a<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-8],data = red_EU_review)

c_NPP_b<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-9],data = red_EU_review)

c_NPP_l<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-10],data = red_EU_review)

c_NPP_w<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-11],data = red_EU_review)

c_NPP_wl<- mgcv::gam(log(Deer_density) ~ hunting + Predation_adj + s(Human_influence_index, by = Predation_adj)+ s(Tree_canopy_cover)+ s(NDSI_Snow_Cover) + s(Palmer_drought_summer) + Protected, sp = c$sp[-12],data = red_EU_review)

c0<- mgcv::gam(log(Deer_density) ~ 1, data = red_EU_review)


dev_hunt<- ((c_hunt$deviance-c$deviance)/c0$deviance)*100
dev_pred<- ((c_pred$deviance-c$deviance)/c0$deviance)*100
dev_prot<- ((c_prot$deviance-c$deviance)/c0$deviance)*100
dev_tcc<- ((c_tcc$deviance-c$deviance)/c0$deviance)*100
dev_ndsi<- ((c_ndsi$deviance-c$deviance)/c0$deviance)*100
dev_pd<- ((c_pd$deviance-c$deviance)/c0$deviance)*100


dev_HIIn<- ((c_HII_n$deviance-c$deviance)/c0$deviance)*100
dev_HIIa<- ((c_HII_a$deviance-c$deviance)/c0$deviance)*100
dev_HIIb<- ((c_HII_b$deviance-c$deviance)/c0$deviance)*100
dev_HIIl<- ((c_HII_l$deviance-c$deviance)/c0$deviance)*100
dev_HIIw<- ((c_HII_w$deviance-c$deviance)/c0$deviance)*100
dev_HIIwl<- ((c_HII_wl$deviance-c$deviance)/c0$deviance)*100

dev_NPPn<- ((c_NPP_n$deviance-c$deviance)/c0$deviance)*100
dev_NPPa<- ((c_NPP_a$deviance-c$deviance)/c0$deviance)*100
dev_NPPb<- ((c_NPP_b$deviance-c$deviance)/c0$deviance)*100
dev_NPPl<- ((c_NPP_l$deviance-c$deviance)/c0$deviance)*100
dev_NPPw<- ((c_NPP_w$deviance-c$deviance)/c0$deviance)*100
dev_NPPwl<- ((c_NPP_wl$deviance-c$deviance)/c0$deviance)*100

